# addToCart
Simple add items to cart feature
